<div style="bottom: 50px; right: 19px;" class="fixed-action-btn direction-top"><a
        class="btn-floating btn-large gradient-45deg-light-blue-cyan gradient-shadow"><i
            class="material-icons">add</i></a>
    <ul>
        <li><a href="css-helpers" class="btn-floating blue"><i class="material-icons">help_outline</i></a></li>
        <li><a href="cards-extended" class="btn-floating green"><i class="material-icons">widgets</i></a></li>
        <li><a href="app-calendar" class="btn-floating amber"><i class="material-icons">today</i></a></li>
        <li><a href="app-email" class="btn-floating red"><i class="material-icons">mail_outline</i></a></li>
    </ul>
</div>